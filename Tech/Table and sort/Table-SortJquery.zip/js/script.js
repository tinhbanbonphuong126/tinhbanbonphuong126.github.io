// A $( document ).ready() block.
$( document ).ready(function() {
    console.log( "ready!" );
    $('#myTable').DataTable();






});