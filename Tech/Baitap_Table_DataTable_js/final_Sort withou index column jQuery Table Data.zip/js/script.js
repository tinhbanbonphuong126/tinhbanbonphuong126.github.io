//$(document).ready(function() {
//
//
//
//    //Set table by datatable.js
//    //if using selector id for 1 object
//    //$('#example').DataTable( {
//
//    //if using selector class for multitable
//    $('table.display').DataTable( {
//        //Feature enable / disable at default
//        //reference here: https://datatables.net/reference/option/
//        //"scrollX": true,
//        //scroll horizon
////         "scrollY":        "400px",
//        "scrollCollapse": true,
//        "paging":         true,
//        //Pagination set and scroll collapse
//        "ordering": true,
//        //set ordering columm
//        "info":     true,
//        //set infor pagination
//        stateSave: true,
//        //save status
//        "order": [[ 0, 'asc' ], [ 3, 'dsc' ]]
//        //set column order at default
//
//
//    } );
//
//} );